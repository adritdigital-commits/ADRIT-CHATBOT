import React from 'react';
import { Target, Monitor, Cpu, Sparkles, CheckCircle2, TrendingUp, Filter, Share2, Palette, Layout, BarChart3 } from 'lucide-react';

const iconMap = { Target, Monitor, Cpu, Sparkles, TrendingUp, Filter, Share2, Palette, Layout, BarChart3 };

export function ServiceCard({ title, icon, description, features }) {
  const IconComponent = iconMap[icon] || Target;

  return (
    <div className="glass-card rounded-2xl p-8 flex flex-col h-full group">
      <div className="w-14 h-14 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors shadow-[0_0_15px_rgba(0,229,255,0.1)] group-hover:shadow-[0_0_20px_rgba(0,229,255,0.3)]">
        <IconComponent className="w-7 h-7 text-primary drop-shadow-[0_0_5px_rgba(0,229,255,0.6)] group-hover:drop-shadow-[0_0_10px_rgba(0,229,255,0.9)] transition-all" />
      </div>
      <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-primary transition-colors">{title}</h3>
      <p className="text-foreground/80 leading-relaxed mb-6 flex-grow">{description}</p>
      <ul className="space-y-3 mt-auto">
        {features.map((feature, idx) => (
          <li key={idx} className="flex items-start text-sm text-foreground/90">
            <CheckCircle2 className="w-4 h-4 text-primary mr-2 mt-0.5 shrink-0 drop-shadow-[0_0_2px_rgba(0,229,255,0.5)]" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}