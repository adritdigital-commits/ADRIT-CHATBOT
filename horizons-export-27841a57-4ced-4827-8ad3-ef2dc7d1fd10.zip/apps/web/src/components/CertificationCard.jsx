import React from 'react';
import { Award } from 'lucide-react';

function CertificationCard({ name, issuer, year }) {
  return (
    <div className="glass-card rounded-xl p-6 flex items-start gap-4">
      <div className="w-12 h-12 bg-primary/10 border border-primary/30 rounded-lg flex items-center justify-center flex-shrink-0 shadow-[0_0_10px_rgba(0,229,255,0.2)]">
        <Award className="w-6 h-6 text-primary drop-shadow-[0_0_5px_rgba(0,229,255,0.8)]" />
      </div>
      <div>
        <h3 className="font-semibold text-white mb-1">{name}</h3>
        <p className="text-sm text-foreground/80">{issuer}</p>
        {year && <p className="text-xs text-primary/70 mt-1">{year}</p>}
      </div>
    </div>
  );
}

export default CertificationCard;