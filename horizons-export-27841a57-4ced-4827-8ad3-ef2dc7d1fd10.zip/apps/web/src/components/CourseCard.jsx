import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, BookOpen, BarChart } from 'lucide-react';

function CourseCard({ title, level, lessons, description, price, features }) {
  const handleEnrollClick = () => {
    window.open(`https://wa.me/919632047883?text=Hi, I want to enroll in ${title}`, '_blank');
  };

  const getLevelColor = (level) => {
    switch(level.toLowerCase()) {
      case 'beginner': return 'bg-green-500/10 text-green-400';
      case 'intermediate': return 'bg-yellow-500/10 text-yellow-400';
      case 'advanced': return 'bg-red-500/10 text-red-400';
      default: return 'bg-blue-500/10 text-blue-400';
    }
  };

  return (
    <div className="bg-[#1a2d3d] text-white rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col h-full">
      <div className="flex items-center gap-3 mb-4">
        <Badge className={`${getLevelColor(level)} border-0`}>
          <BarChart className="w-3 h-3 mr-1" />
          {level}
        </Badge>
        <Badge className="bg-[hsl(210,100%,50%)]/10 text-[hsl(210,100%,50%)] border-0">
          <BookOpen className="w-3 h-3 mr-1" />
          {lessons} Lessons
        </Badge>
      </div>
      
      <h3 className="text-2xl font-bold mb-3">{title}</h3>
      <p className="text-white/80 leading-relaxed mb-6">{description}</p>
      
      {features && features.length > 0 && (
        <ul className="space-y-2 mb-6 flex-grow">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start gap-2 text-sm text-white/70">
              <span className="text-[hsl(210,100%,50%)] mt-0.5">•</span>
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      )}
      
      <div className="mt-auto pt-4 border-t border-white/10">
        <div className="flex items-center justify-between mb-4">
          <span className="text-3xl font-bold">₹{price.toLocaleString('en-IN')}</span>
          <span className="text-white/60 text-sm">One-time payment</span>
        </div>
        <Button 
          onClick={handleEnrollClick}
          className="w-full bg-[#25D366] hover:bg-[#20BD5A] text-white transition-all duration-200 active:scale-[0.98]"
        >
          <MessageCircle className="w-4 h-4 mr-2" />
          Enroll via WhatsApp
        </Button>
      </div>
    </div>
  );
}

export default CourseCard;