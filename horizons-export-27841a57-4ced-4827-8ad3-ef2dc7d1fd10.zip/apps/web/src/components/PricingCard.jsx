import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, Check } from 'lucide-react';

function PricingCard({ title, price, period, features, popular, description }) {
  const handleWhatsAppClick = () => {
    window.open(`https://wa.me/919632047883?text=Hi, I am interested in the ${title} package`, '_blank');
  };

  return (
    <div className={`relative bg-[#1a2d3d] text-white rounded-2xl p-8 transition-all duration-300 flex flex-col h-full ${
      popular ? 'ring-2 ring-[hsl(210,100%,50%)] scale-105' : 'hover:shadow-xl hover:-translate-y-1'
    }`}>
      {popular && (
        <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[hsl(210,100%,50%)] text-white px-4 py-1">
          Most Popular
        </Badge>
      )}
      
      <div className="mb-6">
        <h3 className="text-2xl font-bold mb-2">{title}</h3>
        {description && <p className="text-white/70 text-sm mb-4">{description}</p>}
        <div className="flex items-baseline gap-2">
          <span className="text-4xl font-bold">₹{price.toLocaleString('en-IN')}</span>
          {period && <span className="text-white/60">/{period}</span>}
        </div>
      </div>
      
      <ul className="space-y-3 mb-8 flex-grow">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start gap-3">
            <Check className="w-5 h-5 text-[hsl(210,100%,50%)] mt-0.5 flex-shrink-0" />
            <span className="text-white/90">{feature}</span>
          </li>
        ))}
      </ul>
      
      <div className="mt-auto">
        <Button 
          onClick={handleWhatsAppClick}
          className={`w-full transition-all duration-200 active:scale-[0.98] ${
            popular 
              ? 'bg-[hsl(210,100%,50%)] hover:bg-[hsl(210,100%,45%)] text-white' 
              : 'bg-[#25D366] hover:bg-[#20BD5A] text-white'
          }`}
        >
          <MessageCircle className="w-4 h-4 mr-2" />
          Get Started
        </Button>
      </div>
    </div>
  );
}

export default PricingCard;