import React from 'react';
import { Link } from 'react-router-dom';
import { Linkedin, Mail, Phone } from 'lucide-react';
export default function Footer() {
  return <footer className="bg-[#050709] text-foreground pt-16 pb-8 border-t border-primary/10 relative overflow-hidden">
      {/* Subtle glow effect behind footer */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[300px] bg-primary/5 blur-[100px] pointer-events-none rounded-full"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 mb-12">
          
          {/* Brand Section */}
          <div className="md:col-span-5">
            <Link to="/" className="text-2xl font-bold tracking-tight mb-4 inline-block text-white glow-text">
              RakeshProTech
            </Link>
            <p className="text-foreground/80 max-w-sm leading-relaxed">
              Digital Marketing & Tech Consulting for Startups, Institutions & Local Businesses. Empowering growth with data and execution.
            </p>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3">
            <h4 className="text-lg font-semibold text-white mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {['Home', 'Services', 'About', 'Contact', 'Portfolio'].map(item => <li key={item}>
                  <Link to={item === 'Home' ? '/' : `/${item.toLowerCase()}`} className="text-primary hover:text-white hover:glow-text transition-all duration-300">
                    {item}
                  </Link>
                </li>)}
            </ul>
          </div>

          {/* Contact Info */}
          <div className="md:col-span-4">
            <h4 className="text-lg font-semibold text-white mb-6">Contact</h4>
            <ul className="space-y-4 mb-6">
              <li>
                <a href="tel:+919632047883" className="flex items-center gap-3 text-foreground/80 hover:text-primary transition-colors duration-300 group">
                  <Phone className="w-5 h-5 text-primary group-hover:drop-shadow-[0_0_5px_rgba(0,229,255,0.8)]" />
                  +91 96320 47883
                </a>
              </li>
              <li>
                <a href="mailto:rakeshrockstar928@gmail.com" className="flex items-center gap-3 text-foreground/80 hover:text-primary transition-colors duration-300 group">
                  <Mail className="w-5 h-5 text-primary group-hover:drop-shadow-[0_0_5px_rgba(0,229,255,0.8)]" />
                  hello@rakeshprotech.in
                </a>
              </li>
            </ul>
            <a href="https://www.linkedin.com/in/rakeshprotech/" target="_blank" rel="noreferrer" className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 border border-primary/20 text-primary hover:bg-primary hover:text-primary-foreground hover:shadow-[0_0_15px_rgba(0,229,255,0.4)] transition-all duration-300" aria-label="LinkedIn">
              <Linkedin className="w-5 h-5" />
            </a>
          </div>
        </div>

        <div className="border-t border-primary/15 pt-8 text-center md:text-left flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-foreground/50">
          <p>© 2026 RakeshProTech. All rights reserved.</p>
          <p>Designed and managed by <span className="text-primary/70">Rakesh M R</span>, Bengaluru</p>
        </div>
      </div>
    </footer>;
}