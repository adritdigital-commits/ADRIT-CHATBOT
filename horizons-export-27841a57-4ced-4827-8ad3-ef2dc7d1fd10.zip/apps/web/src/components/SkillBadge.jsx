import React from 'react';

function SkillBadge({ skill }) {
  return (
    <div className="bg-[#1a2d3d] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-[hsl(210,100%,50%)] transition-all duration-200 cursor-default">
      {skill}
    </div>
  );
}

export default SkillBadge;