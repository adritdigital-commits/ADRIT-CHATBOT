import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Calendar } from 'lucide-react';

export function BlogCard({ slug, title, category, excerpt, date, thumbnail }) {
  const formattedDate = new Date(date).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric'
  });

  return (
    <Link to={`/blog/${slug}`} className="group flex flex-col h-full bg-card border border-border rounded-2xl overflow-hidden hover:shadow-lg transition-all duration-300">
      <div className="relative h-56 overflow-hidden">
        <img src={thumbnail} alt={title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
        <div className="absolute top-4 left-4 bg-accent text-accent-foreground text-xs font-bold px-3 py-1.5 rounded-full uppercase tracking-wider">
          {category}
        </div>
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex items-center text-muted-foreground text-sm mb-3">
          <Calendar className="w-4 h-4 mr-2" /> {formattedDate}
        </div>
        <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-accent transition-colors line-clamp-2">
          {title}
        </h3>
        <p className="text-muted-foreground leading-relaxed mb-6 flex-grow line-clamp-3">
          {excerpt}
        </p>
        <div className="mt-auto flex items-center text-primary font-medium group-hover:text-accent transition-colors">
          Read More <ArrowRight className="w-4 h-4 ml-2 transform transition-transform group-hover:translate-x-1" />
        </div>
      </div>
    </Link>
  );
}