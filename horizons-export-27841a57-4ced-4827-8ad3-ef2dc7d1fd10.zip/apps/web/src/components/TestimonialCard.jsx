import React from 'react';
import { Star, Quote } from 'lucide-react';

export function TestimonialCard({ name, role, text, rating, company }) {
  return (
    <div className="glass-card rounded-2xl p-8 relative group">
      <Quote className="absolute top-6 right-6 w-10 h-10 text-primary/10 group-hover:text-primary/20 transition-colors duration-300" />
      
      <div className="flex gap-1 mb-6">
        {[...Array(rating || 5)].map((_, i) => (
          <Star key={i} className="w-5 h-5 fill-primary text-primary drop-shadow-[0_0_3px_rgba(0,229,255,0.6)]" />
        ))}
      </div>
      
      <p className="text-lg leading-relaxed mb-8 italic text-foreground/90">
        "{text}"
      </p>
      
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center font-bold text-lg text-primary shadow-[0_0_10px_rgba(0,229,255,0.2)]">
          {name.charAt(0)}
        </div>
        <div>
          <h4 className="font-bold text-white">{name}</h4>
          <p className="text-sm text-primary/80">{role || company}</p>
        </div>
      </div>
    </div>
  );
}