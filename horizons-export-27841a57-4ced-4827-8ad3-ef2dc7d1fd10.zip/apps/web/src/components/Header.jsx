import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'About', path: '/about' },
    { name: 'Portfolio', path: '/portfolio' },
    { name: 'Contact', path: '/contact' }
  ];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled 
        ? 'bg-[#0A0E14]/95 backdrop-blur-md shadow-[0_4px_30px_rgba(0,229,255,0.05)] border-b border-primary/10 py-3' 
        : 'bg-transparent py-5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-white tracking-tight z-50 glow-text transition-all duration-300 hover:scale-105">
          RakeshProTech
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link 
              key={link.name} 
              to={link.path}
              className={`text-sm font-medium transition-all duration-300 relative group ${
                location.pathname === link.path ? 'text-primary' : 'text-foreground hover:text-primary'
              }`}
            >
              {link.name}
              <span className={`absolute -bottom-1 left-0 w-full h-0.5 bg-primary transform origin-left transition-transform duration-300 ${
                location.pathname === link.path ? 'scale-x-100 glow-text' : 'scale-x-0 group-hover:scale-x-100'
              }`}></span>
            </Link>
          ))}
        </nav>

        {/* Desktop CTA */}
        <div className="hidden lg:flex items-center gap-6">
          <a href="tel:+919632047883" className="flex items-center gap-2 text-sm font-medium text-foreground hover:text-primary hover:glow-text transition-all duration-300">
            <Phone className="w-4 h-4" />
            +91 96320 47883
          </a>
          <Link to="/contact">
            <Button className="bg-primary text-primary-foreground hover:bg-primary hover:brightness-110 rounded-full px-6 btn-glow animate-pulse-glow border-none">
              Get Free Consultation
            </Button>
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="lg:hidden z-50 text-white p-2 hover:text-primary transition-colors"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle Menu"
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>

        {/* Mobile Nav Overlay */}
        <div className={`fixed inset-0 bg-[#0A0E14] z-40 transition-transform duration-300 ease-in-out ${
          isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        } lg:hidden flex flex-col pt-24 px-6`}>
          <nav className="flex flex-col gap-6 text-xl font-medium">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                to={link.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={`border-b border-primary/20 pb-4 transition-all duration-300 ${
                  location.pathname === link.path ? 'text-primary glow-text' : 'text-white hover:text-primary'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>
          <div className="mt-8 flex flex-col gap-4">
            <a href="tel:+919632047883" className="flex items-center gap-2 text-lg font-medium text-foreground hover:text-primary transition-colors">
              <Phone className="w-5 h-5 text-primary" />
              +91 96320 47883
            </a>
            <Link to="/contact" onClick={() => setIsMobileMenuOpen(false)}>
              <Button size="lg" className="w-full bg-primary text-primary-foreground rounded-full btn-glow animate-pulse-glow border-none">
                Get Free Consultation
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}