import React from 'react';
import { Target, Users, TrendingUp, Headphones } from 'lucide-react';

const iconMap = {
  'Target': Target,
  'Users': Users,
  'TrendingUp': TrendingUp,
  'Headphones': Headphones
};

function FeatureBox({ icon, title, description }) {
  const IconComponent = iconMap[icon];

  if (!IconComponent) {
    return null;
  }

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="w-12 h-12 bg-primary/10 border border-primary/30 rounded-lg flex items-center justify-center mb-4 shadow-[0_0_10px_rgba(0,229,255,0.2)]">
        <IconComponent className="w-6 h-6 text-primary drop-shadow-[0_0_5px_rgba(0,229,255,0.8)]" />
      </div>
      <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
      <p className="text-foreground/80 leading-relaxed">{description}</p>
    </div>
  );
}

export default FeatureBox;