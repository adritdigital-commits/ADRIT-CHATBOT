import React from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export function CTAButton({ children, variant = 'primary', className, ...props }) {
  const baseStyles = "transition-all duration-300 active:scale-[0.98] font-medium px-6 py-6 text-base rounded-xl";
  
  const variants = {
    primary: "bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(212,175,55,0.3)]",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 border border-border",
    outline: "bg-transparent border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground"
  };

  return (
    <Button 
      className={cn(baseStyles, variants[variant], className)} 
      {...props}
    >
      {children}
    </Button>
  );
}