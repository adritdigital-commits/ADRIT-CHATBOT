import React from 'react';

export function ProcessStep({ step, title, description, isLast }) {
  return (
    <div className="relative flex flex-col md:flex-row gap-6 md:gap-8 flex-1 group">
      {!isLast && (
        <div className="hidden md:block absolute top-8 left-16 right-[-2rem] h-px bg-gradient-to-r from-primary/50 to-primary/10 shadow-[0_0_10px_rgba(0,229,255,0.3)] transition-all duration-300 group-hover:from-primary" />
      )}
      {!isLast && (
        <div className="md:hidden absolute left-8 top-16 bottom-[-2rem] w-px bg-gradient-to-b from-primary/50 to-primary/10 shadow-[0_0_10px_rgba(0,229,255,0.3)] transition-all duration-300 group-hover:from-primary" />
      )}
      
      <div className="relative z-10 flex-shrink-0 w-16 h-16 rounded-full bg-primary/10 border-2 border-primary flex items-center justify-center shadow-[0_0_15px_rgba(0,229,255,0.2)] transition-all duration-300 group-hover:shadow-[0_0_25px_rgba(0,229,255,0.5)] group-hover:bg-primary/20 group-hover:scale-110">
        <span className="text-primary font-bold text-xl drop-shadow-[0_0_5px_rgba(0,229,255,0.8)]">{step}</span>
      </div>
      
      <div className="pb-8 md:pb-0 md:pt-20">
        <h3 className="text-xl font-bold text-white mb-3 transition-colors duration-300 group-hover:text-primary">{title}</h3>
        <p className="text-foreground/80 leading-relaxed">{description}</p>
      </div>
    </div>
  );
}