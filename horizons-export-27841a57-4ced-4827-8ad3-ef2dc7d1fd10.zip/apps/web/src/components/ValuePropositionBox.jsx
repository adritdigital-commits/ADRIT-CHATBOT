import React from 'react';
import { MessageSquare, Settings, PiggyBank, Zap, TrendingUp, HeartHandshake, CheckCircle2 } from 'lucide-react';

const iconMap = {
  'Data-Driven Mindset': TrendingUp,
  'Hands-On Execution': Zap,
  'Tech + Marketing Blend': Settings,
  'Founder-Led Service': HeartHandshake,
  'Direct Founder Communication': MessageSquare,
  'Affordable Business Solutions': PiggyBank
};

export function ValuePropositionBox({ title, description }) {
  const IconComponent = iconMap[title] || CheckCircle2;

  return (
    <div className="glass-card flex gap-4 p-6 rounded-xl group">
      <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center shadow-[0_0_10px_rgba(0,229,255,0.15)] group-hover:shadow-[0_0_20px_rgba(0,229,255,0.4)] group-hover:bg-primary/20 transition-all duration-300">
        <IconComponent className="w-6 h-6 text-primary drop-shadow-[0_0_5px_rgba(0,229,255,0.8)]" />
      </div>
      <div>
        <h3 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">{title}</h3>
        <p className="text-foreground/80 text-sm leading-relaxed">{description}</p>
      </div>
    </div>
  );
}