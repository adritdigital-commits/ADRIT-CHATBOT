import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { CheckCircle2, ArrowRight } from 'lucide-react';
import { servicesData } from '@/data/mockData.js';

export default function ServicesPage() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <main className="min-h-screen pt-24 pb-20 bg-background overflow-hidden">
      <Helmet>
        <title>Our Services | RakeshProTech</title>
      </Helmet>

      <section className="py-16 relative">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[300px] bg-primary/10 rounded-full mix-blend-screen filter blur-[120px] pointer-events-none"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight"
          >
            Capabilities & <span className="text-primary glow-text">Systems</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-foreground/80 max-w-2xl mx-auto"
          >
            Comprehensive digital marketing and tech consulting solutions designed to engineer measurable growth.
          </motion.p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-32">
            {servicesData.map((service, index) => (
              <motion.div 
                key={service.id} 
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-100px" }}
                variants={containerVariants}
                className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start"
              >
                <motion.div variants={itemVariants} className="lg:col-span-5 lg:sticky lg:top-32">
                  <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 leading-tight">{service.title}</h2>
                  <p className="text-lg text-foreground/70 mb-8 leading-relaxed">{service.details}</p>
                  <Link to="/contact">
                    <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 h-12 btn-glow border-none font-bold">
                      Deploy System
                    </Button>
                  </Link>
                </motion.div>
                
                <motion.div variants={itemVariants} className="lg:col-span-7 space-y-8">
                  <div className="glass-card p-8 md:p-10 rounded-2xl">
                    <h3 className="text-xl font-bold text-primary mb-6 flex items-center gap-3">
                      <span className="w-2 h-2 rounded-full bg-primary animate-pulse shadow-[0_0_8px_rgba(0,229,255,0.8)]"></span>
                      Core Components
                    </h3>
                    <ul className="space-y-4">
                      {service.included.map((item, i) => (
                        <li key={i} className="flex items-start gap-3 group">
                          <CheckCircle2 className="w-5 h-5 text-primary/70 shrink-0 mt-0.5 group-hover:text-primary group-hover:drop-shadow-[0_0_5px_rgba(0,229,255,0.8)] transition-all" />
                          <span className="text-white/80 group-hover:text-white transition-colors">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="glass-card p-8 md:p-10 rounded-2xl border-secondary/20 shadow-[0_0_15px_rgba(168,85,247,0.05)]">
                    <h3 className="text-xl font-bold text-secondary mb-6 flex items-center gap-3">
                      <span className="w-2 h-2 rounded-full bg-secondary animate-pulse shadow-[0_0_8px_rgba(168,85,247,0.8)]"></span>
                      Execution Protocol
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      {service.process.map((step, i) => (
                        <div key={i} className="flex items-center gap-4 p-4 rounded-xl bg-background/50 border border-border/10">
                          <div className="w-8 h-8 rounded-lg bg-secondary/10 border border-secondary/30 text-secondary flex items-center justify-center font-bold text-sm shrink-0 shadow-[0_0_10px_rgba(168,85,247,0.2)]">
                            {i + 1}
                          </div>
                          <span className="font-medium text-white/90">{step}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 relative mt-20 border-t border-primary/10">
        <div className="absolute inset-0 bg-primary/5"></div>
        <div className="max-w-3xl mx-auto px-4 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Require a custom <span className="text-primary glow-text">architecture?</span></h2>
            <p className="text-lg text-foreground/80 mb-10">Book a strategy call and we'll engineer a specific solution for your operational bottlenecks.</p>
            <Link to="/contact">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-10 h-14 text-lg btn-glow animate-pulse-glow border-none font-bold">
                Initialize Consultation
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </main>
  );
}