import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Phone, Mail, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Button } from '@/components/ui/button';

export default function ConsultationPage() {
  const [formData, setFormData] = useState({ 
    name: '', 
    email: '', 
    phone: '', 
    service: 'Performance Marketing', 
    message: '' 
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const subject = `New Consultation Request from ${formData.name}`;
    const body = `Name: ${formData.name}%0D%0AEmail: ${formData.email}%0D%0APhone: ${formData.phone}%0D%0AService: ${formData.service}%0D%0A%0D%0AMessage:%0D%0A${formData.message}`;
    window.location.href = `mailto:rakesh@rakeshprotech.online?subject=${subject}&body=${body}`;
    toast.success('Redirecting to your email client...');
    setFormData({ name: '', email: '', phone: '', service: 'Performance Marketing', message: '' });
  };

  return (
    <main className="min-h-screen pt-32 pb-24 bg-background">
      <Helmet><title>Book Consultation | RakeshProTech</title></Helmet>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="text-4xl md:text-6xl font-bold font-serif text-primary mb-6">Book Your Free Consultation</h1>
          <p className="text-xl text-muted-foreground">Let's discuss your business goals and create a growth strategy together.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          {/* Form */}
          <div className="lg:col-span-2">
            <div className="bg-card border border-border p-8 md:p-10 rounded-2xl shadow-sm">
              <h3 className="text-2xl font-bold font-serif text-primary mb-8">Tell me about your business</h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name *</Label>
                    <Input 
                      id="name" 
                      required 
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})} 
                      placeholder="Jane Doe"
                      className="h-12 bg-background border-border text-foreground"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address *</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      required 
                      value={formData.email}
                      onChange={e => setFormData({...formData, email: e.target.value})} 
                      placeholder="jane@company.com"
                      className="h-12 bg-background border-border text-foreground"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input 
                      id="phone" 
                      type="tel" 
                      value={formData.phone}
                      onChange={e => setFormData({...formData, phone: e.target.value})} 
                      placeholder="+91 98765 43210"
                      className="h-12 bg-background border-border text-foreground"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Service Interested In</Label>
                    <Select value={formData.service} onValueChange={(val) => setFormData({...formData, service: val})}>
                      <SelectTrigger className="h-12 bg-background border-border text-foreground">
                        <SelectValue placeholder="Select a service" />
                      </SelectTrigger>
                      <SelectContent className="bg-background border-border">
                        <SelectItem value="Performance Marketing">Performance Marketing</SelectItem>
                        <SelectItem value="Web Presence">Web Presence</SelectItem>
                        <SelectItem value="AI & Automation">AI & Automation</SelectItem>
                        <SelectItem value="Brand & Content">Brand & Content</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message">Message / Details *</Label>
                  <Textarea 
                    id="message" 
                    required 
                    rows={5} 
                    value={formData.message}
                    onChange={e => setFormData({...formData, message: e.target.value})} 
                    placeholder="Tell me a bit about your current challenges and goals..."
                    className="bg-background border-border text-foreground resize-y"
                  />
                </div>
                
                <p className="text-sm text-muted-foreground italic my-4">
                  I personally review every consultation request and respond within 24 hours.
                </p>

                <Button type="submit" size="lg" className="w-full bg-accent text-accent-foreground hover:bg-accent/90 h-14 text-base font-medium">
                  Submit Request
                </Button>
              </form>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-primary text-primary-foreground p-8 md:p-10 rounded-2xl sticky top-32">
              <h3 className="text-2xl font-bold font-serif text-white mb-8">Direct Contact</h3>
              
              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <Phone className="w-6 h-6 text-accent shrink-0" />
                  <div>
                    <p className="font-medium text-white mb-1">WhatsApp / Phone</p>
                    <a href="https://wa.me/919632047883" className="text-[#F7F5F0]/70 hover:text-accent transition-colors">+91 96320 47883</a>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <Mail className="w-6 h-6 text-accent shrink-0" />
                  <div>
                    <p className="font-medium text-white mb-1">Email</p>
                    <a href="mailto:rakesh@rakeshprotech.online" className="text-[#F7F5F0]/70 hover:text-accent transition-colors break-all">rakesh@rakeshprotech.online</a>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <MapPin className="w-6 h-6 text-accent shrink-0" />
                  <div>
                    <p className="font-medium text-white mb-1">Location</p>
                    <p className="text-[#F7F5F0]/70">Bengaluru, India</p>
                  </div>
                </div>
              </div>

              <div className="mt-10 pt-8 border-t border-white/10">
                <a href="https://wa.me/919632047883" target="_blank" rel="noreferrer">
                  <Button className="w-full bg-[#25D366] hover:bg-[#20BD5A] text-white h-14 text-base font-medium border-0">
                    Message on WhatsApp
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}