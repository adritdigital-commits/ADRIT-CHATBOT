import React from 'react';
import { useParams, Navigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { blogData } from '@/data/mockData.js';

export default function BlogPostPage() {
  const { slug } = useParams();
  const post = blogData.find(p => p.slug === slug);

  if (!post) return <Navigate to="/blog" replace />;

  const formattedDate = new Date(post.date).toLocaleDateString('en-US', {
    month: 'long', day: 'numeric', year: 'numeric'
  });

  const relatedPosts = blogData.filter(p => p.id !== post.id).slice(0, 2);

  return (
    <main className="min-h-screen pt-20 pb-20">
      <Helmet>
        <title>{post.title} | RakeshProTech</title>
      </Helmet>

      <article>
        <div className="w-full h-[40vh] md:h-[50vh] relative">
          <img 
            src={post.thumbnail} 
            alt={post.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-primary/60"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="max-w-4xl mx-auto px-4 text-center text-white">
              <span className="inline-block px-4 py-1.5 bg-accent text-accent-foreground text-sm font-bold rounded-full mb-6 uppercase tracking-wider">
                {post.category}
              </span>
              <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                {post.title}
              </h1>
              <div className="flex items-center justify-center gap-4 text-white/80 font-medium">
                <span>{post.author}</span>
                <span>•</span>
                <span>{formattedDate}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div 
            className="prose prose-lg max-w-none prose-headings:text-primary prose-a:text-accent hover:prose-a:text-accent/80"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />
        </div>
      </article>

      <section className="py-16 bg-muted/30 border-t border-border">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h3 className="text-2xl font-bold text-primary mb-6">Have questions?</h3>
          <a href="https://wa.me/919632047883" target="_blank" rel="noreferrer">
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BD5A] text-white rounded-full px-8">
              Chat with Rakesh on WhatsApp
            </Button>
          </a>
        </div>
      </section>

      {relatedPosts.length > 0 && (
        <section className="py-16 bg-background border-t border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h3 className="text-2xl font-bold text-primary mb-8">Related Articles</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {relatedPosts.map(related => (
                <Link key={related.id} to={`/blog/${related.slug}`} className="flex gap-6 bg-card border border-border p-4 rounded-xl hover:shadow-md transition-shadow">
                  <div className="w-32 h-32 rounded-lg overflow-hidden shrink-0 hidden sm:block">
                    <img src={related.thumbnail} alt={related.title} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-primary mb-2 line-clamp-2">{related.title}</h4>
                    <p className="text-muted-foreground text-sm line-clamp-2">{related.excerpt}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </main>
  );
}