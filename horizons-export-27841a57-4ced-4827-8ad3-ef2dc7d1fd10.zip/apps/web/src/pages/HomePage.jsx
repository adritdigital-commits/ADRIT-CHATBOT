import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { 
  TrendingUp, Globe, Bot, PenTool, ArrowRight, PlayCircle, Volume2, VolumeX, 
  CheckCircle2, Building2, GraduationCap, Store, Presentation, Phone, Star,
  Target, Filter, Share2, Palette, Layout, BarChart3
} from 'lucide-react';
import { servicesData } from '@/data/mockData.js';
import { ServiceCard } from '@/components/ServiceCard.jsx';
import { TestimonialCard } from '@/components/TestimonialCard.jsx';
import { ValuePropositionBox } from '@/components/ValuePropositionBox.jsx';
import { ProcessStep } from '@/components/ProcessStep.jsx';

export default function HomePage() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
  };

  return (
    <main className="min-h-screen pt-20 bg-background overflow-hidden">
      <Helmet>
        <title>RakeshProTech | Digital Marketing & Tech Consulting</title>
        <meta name="description" content="RakeshProTech — Digital marketing consultant in Bengaluru specializing in Meta Ads, Google Ads, lead generation, and WordPress websites for startups and institutions." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative py-24 lg:py-40 text-foreground overflow-hidden">
        {/* Animated Gradient Mesh Background */}
        <div className="absolute inset-0 z-0">
          <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-primary/20 rounded-full mix-blend-screen filter blur-[120px] opacity-60 animate-pulse animate-float"></div>
          <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-secondary/20 rounded-full mix-blend-screen filter blur-[100px] opacity-60 animate-float-slow"></div>
          <div className="absolute inset-0 bg-background/50 backdrop-blur-[2px]"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-5xl md:text-7xl font-extrabold leading-tight mb-6 text-white tracking-tight">
              <span className="text-primary glow-text">Grow</span> Your Business <br className="hidden sm:block"/>
              <span className="text-primary glow-text">Online.</span> We Handle Marketing,<br className="hidden sm:block"/> You Handle Growth.
            </h1>
            <p className="text-lg md:text-xl text-foreground/80 mb-10 leading-relaxed max-w-2xl mx-auto">
              Performance marketing, lead generation, and digital growth for startups, educational institutions, and local businesses. Data-driven strategy. Hands-on execution. Real results.
            </p>
            <div className="flex flex-col sm:flex-row gap-5 justify-center mb-16">
              <Link to="/contact">
                <Button size="lg" className="w-full sm:w-auto bg-primary text-primary-foreground hover:bg-primary/90 rounded-full h-14 px-8 text-base btn-glow animate-pulse-glow border-none">
                  Get a Free Audit
                </Button>
              </Link>
              <Link to="/services">
                <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent border-primary/50 text-white hover:bg-primary/10 hover:border-primary rounded-full h-14 px-8 text-base shadow-[0_0_15px_rgba(0,229,255,0.1)] hover:shadow-[0_0_20px_rgba(0,229,255,0.3)] transition-all duration-300">
                  View Our Services
                </Button>
              </Link>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-10 border-t border-primary/20 max-w-3xl mx-auto">
              {[
                { label: '1.3+ Years at Boston Institute of Analytics' },
                { label: 'Meta & Google Ads Hands-On' },
                { label: 'Cybersecurity + Marketing Background' }
              ].map((stat, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 + (i * 0.1) }}
                  className="flex flex-col items-center gap-2 glass-card py-4 px-2 rounded-xl"
                >
                  <CheckCircle2 className="w-6 h-6 text-primary drop-shadow-[0_0_8px_rgba(0,229,255,0.8)] animate-float" style={{ animationDelay: `${i * 0.6}s` }} />
                  <span className="font-medium text-sm text-white text-center">{stat.label}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={containerVariants}
            className="text-center max-w-3xl mx-auto mb-16"
          >
            <motion.h2 variants={itemVariants} className="text-3xl md:text-5xl font-bold text-white mb-6 tracking-tight">Core <span className="text-primary glow-text">Services</span></motion.h2>
            <motion.p variants={itemVariants} className="text-lg text-foreground/80">Comprehensive digital solutions to scale your operations and dominate your market.</motion.p>
          </motion.div>
          
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16"
          >
            {servicesData.slice(0, 6).map((service, index) => (
              <motion.div key={service.id} variants={itemVariants} className="h-full">
                <ServiceCard 
                  title={service.title}
                  icon={service.icon}
                  description={service.description}
                  features={service.included.slice(0, 3)}
                />
              </motion.div>
            ))}
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <Link to="/services">
              <Button variant="outline" className="rounded-full px-8 h-12 border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground shadow-[0_0_15px_rgba(0,229,255,0.1)] hover:shadow-[0_0_25px_rgba(0,229,255,0.4)] transition-all duration-300">
                Explore All Services <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-primary/5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Why Choose <span className="text-primary glow-text">RakeshProTech</span></h2>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { title: 'Data-Driven Mindset', desc: 'We don\'t guess. Every decision is backed by analytics and performance metrics.' },
              { title: 'Hands-On Execution', desc: 'You work directly with the person building your campaigns, not an account manager.' },
              { title: 'Tech + Marketing Blend', desc: 'Deep understanding of the technical infrastructure that powers modern marketing.' },
              { title: 'Founder-Led Service', desc: 'Personal accountability and a genuine commitment to your business growth.' }
            ].map((item, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <ValuePropositionBox title={item.title} description={item.desc} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Who We Help */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.h2 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-bold text-center text-white mb-16"
          >
            Industries We <span className="text-secondary glow-text-violet">Elevate</span>
          </motion.h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Building2, title: 'Startups', desc: 'Scalable growth strategies to acquire early users and build momentum.' },
              { icon: GraduationCap, title: 'EdTech & Institutes', desc: 'Lead generation for enrollments and brand building for academies.' },
              { icon: Store, title: 'Local Businesses', desc: 'Local SEO and targeted ads to drive foot traffic and local inquiries.' },
              { icon: Presentation, title: 'Coaching & Training', desc: 'Funnel building and personal branding to sell courses and consulting.' }
            ].map((item, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card p-8 rounded-2xl group flex flex-col items-center text-center"
              >
                <div className="w-16 h-16 rounded-2xl bg-secondary/10 border border-secondary/30 flex items-center justify-center mb-6 group-hover:bg-secondary/20 transition-all shadow-[0_0_15px_rgba(168,85,247,0.2)] group-hover:shadow-[0_0_25px_rgba(168,85,247,0.4)]">
                  <item.icon className="w-8 h-8 text-secondary drop-shadow-[0_0_8px_rgba(168,85,247,0.8)]" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-secondary transition-colors">{item.title}</h3>
                <p className="text-foreground/80 text-sm">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/10 rounded-full mix-blend-screen filter blur-[100px] opacity-40"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Our <span className="text-primary glow-text">Process</span></h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto">A systematic, data-backed approach to scaling your operations.</p>
          </motion.div>
          
          <div className="flex flex-col md:flex-row gap-8 justify-between">
            {[
              { step: '01', title: 'Discovery & Audit', desc: 'Deep dive into your current metrics, assets, and market position.' },
              { step: '02', title: 'Strategy Design', desc: 'Custom roadmap building with clear KPIs and resource allocation.' },
              { step: '03', title: 'Deployment', desc: 'Precise execution of campaigns, funnels, and tracking systems.' },
              { step: '04', title: 'Scale & Optimize', desc: 'Continuous data analysis to trim waste and double down on winners.' }
            ].map((item, i, arr) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="flex-1"
              >
                <ProcessStep 
                  step={item.step} 
                  title={item.title} 
                  description={item.desc} 
                  isLast={i === arr.length - 1} 
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials / Principles */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">What I <span className="text-secondary glow-text-violet">Focus On</span></h2>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { quote: "You get clear reporting, honest metrics, and no fluff. I explain what's working, what's not, and why.", name: "Full Transparency on Every Campaign", company: "Core Principle" },
              { quote: "As a founder, I personally manage your campaigns and strategy. No middlemen, no handoffs.", name: "You Talk Directly to Me, Not an Account Manager", company: "Core Principle" },
              { quote: "Every decision is backed by analytics, testing, and real performance data — not creative hunches.", name: "Data-Driven, Not Guesswork", company: "Core Principle" }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <TestimonialCard quote={item.quote} name={item.name} company={item.company} text={item.quote} rating={5} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-16 border-y border-primary/10 relative overflow-hidden">
        <div className="absolute inset-0 bg-background">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/5 via-background to-background"></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h2 className="text-2xl font-bold text-white mb-8">Certified Expertise</h2>
          <div className="flex flex-wrap justify-center gap-4 md:gap-6">
            {['Google Digital Marketing', 'Meta Blueprint Certified', 'EC-Council CSCU', 'CompTIA ITF+', 'IANT Software Programmer'].map((cert, i) => (
              <motion.span 
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="px-5 py-2.5 rounded-full glass-card text-sm md:text-base font-medium text-white hover:text-primary transition-colors cursor-default"
              >
                {cert}
              </motion.span>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass-card rounded-3xl overflow-hidden border border-primary/30 shadow-[0_0_30px_rgba(0,229,255,0.1)] p-0"
          >
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="p-10 lg:p-16">
                <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Ready to <span className="text-primary glow-text">Scale?</span></h2>
                <p className="text-foreground/80 mb-10 text-lg">Let's build a digital growth engine tailored to your exact business model. Drop a message or reach out instantly.</p>
                
                <form action="mailto:rakeshrockstar928@gmail.com" method="POST" encType="text/plain" className="space-y-5">
                  <input type="text" name="Name" placeholder="Your Name" required className="w-full px-5 py-4 rounded-xl bg-input border border-border focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary text-white placeholder:text-foreground/40 transition-all" />
                  <input type="email" name="Email" placeholder="Email Address" required className="w-full px-5 py-4 rounded-xl bg-input border border-border focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary text-white placeholder:text-foreground/40 transition-all" />
                  <textarea name="Message" placeholder="Project Details" rows="4" required className="w-full px-5 py-4 rounded-xl bg-input border border-border focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary text-white placeholder:text-foreground/40 transition-all resize-none"></textarea>
                  <Button type="submit" className="w-full bg-primary text-primary-foreground hover:bg-primary/90 hover:brightness-110 h-14 text-lg rounded-xl btn-glow border-none font-bold">
                    Initialize Contact
                  </Button>
                </form>
              </div>
              
              <div className="bg-primary/5 p-10 lg:p-16 border-t lg:border-t-0 lg:border-l border-primary/20 flex flex-col justify-center relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 rounded-full mix-blend-screen filter blur-[80px]"></div>
                
                <h3 className="text-2xl font-bold text-white mb-8 relative z-10">Direct Channels</h3>
                <div className="space-y-8 mb-12 relative z-10">
                  <a href="tel:+919632047883" className="flex items-center gap-5 group">
                    <div className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-all shadow-[0_0_15px_rgba(0,229,255,0.1)] group-hover:shadow-[0_0_20px_rgba(0,229,255,0.3)]">
                      <Phone className="w-6 h-6 text-primary drop-shadow-[0_0_5px_rgba(0,229,255,0.8)]" />
                    </div>
                    <div>
                      <p className="text-sm text-foreground/60 mb-1">Encrypted Line / WhatsApp</p>
                      <p className="text-xl font-bold text-white group-hover:text-primary transition-colors">+91 96320 47883</p>
                    </div>
                  </a>
                  <a href="mailto:rakeshrockstar928@gmail.com" className="flex items-center gap-5 group">
                    <div className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-all shadow-[0_0_15px_rgba(0,229,255,0.1)] group-hover:shadow-[0_0_20px_rgba(0,229,255,0.3)]">
                      <TrendingUp className="w-6 h-6 text-primary drop-shadow-[0_0_5px_rgba(0,229,255,0.8)]" />
                    </div>
                    <div>
                      <p className="text-sm text-foreground/60 mb-1">Direct Email</p>
                      <p className="text-lg font-bold text-white break-all group-hover:text-primary transition-colors">rakeshrockstar928@gmail.com</p>
                    </div>
                  </a>
                </div>
                
                <div className="flex flex-col gap-4 relative z-10">
                  <a href="https://wa.me/919632047883" target="_blank" rel="noreferrer">
                    <Button className="w-full bg-[#25D366]/20 border border-[#25D366]/50 hover:bg-[#25D366] text-[#25D366] hover:text-white h-14 text-base rounded-xl transition-all duration-300 shadow-[0_0_15px_rgba(37,211,102,0.1)] hover:shadow-[0_0_25px_rgba(37,211,102,0.4)]">
                      Secure WhatsApp Chat
                    </Button>
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </main>
  );
}