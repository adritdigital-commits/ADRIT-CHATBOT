import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Activity } from 'lucide-react';
import { portfolioData } from '@/data/mockData.js';

export default function PortfolioPage() {
  return (
    <main className="min-h-screen pt-24 pb-20 bg-background overflow-hidden">
      <Helmet>
        <title>What I Bring to the Table | RakeshProTech</title>
      </Helmet>

      <section className="py-16 relative">
        <div className="absolute top-0 right-1/4 w-[400px] h-[400px] bg-secondary/10 rounded-full mix-blend-screen filter blur-[100px] pointer-events-none"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight"
          >
            What I Bring to the <span className="text-secondary glow-text-violet">Table</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-foreground/80 max-w-2xl mx-auto"
          >
            Real work examples and ongoing projects demonstrating my approach to digital growth.
          </motion.p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-24">
            {portfolioData.map((item, index) => (
              <motion.div 
                key={item.id} 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="glass-card rounded-2xl overflow-hidden flex flex-col group h-full"
              >
                <div className="p-8 flex-grow">
                  <div className="flex justify-between items-center mb-6">
                    <span className="inline-block px-3 py-1 bg-secondary/10 border border-secondary/30 text-secondary text-xs font-bold rounded-full uppercase tracking-wider shadow-[0_0_10px_rgba(168,85,247,0.1)]">
                      {item.industry}
                    </span>
                    <Activity className="w-5 h-5 text-primary/50 group-hover:text-primary transition-colors" />
                  </div>
                  
                  <h3 className="text-2xl font-bold text-white mb-8 group-hover:text-primary transition-colors">{item.title}</h3>
                  
                  <div className="space-y-6 mb-8">
                    <div>
                      <h4 className="text-xs font-bold text-foreground/50 uppercase tracking-wider mb-2">Scope of Work</h4>
                      <p className="text-foreground/80 text-sm leading-relaxed">{item.challenge}</p>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-foreground/50 uppercase tracking-wider mb-2">Execution</h4>
                      <p className="text-foreground/80 text-sm leading-relaxed">{item.solution}</p>
                    </div>
                  </div>
                </div>
                
                <div className="p-6 border-t border-primary/20 bg-primary/5 mt-auto relative overflow-hidden group-hover:bg-primary/10 transition-colors">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/5 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]"></div>
                  <h4 className="text-xs font-bold text-primary uppercase tracking-wider mb-2 drop-shadow-[0_0_5px_rgba(0,229,255,0.5)]">Status</h4>
                  <p className="text-white font-bold text-lg">{item.results}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="text-center glass-card p-12 md:p-16 rounded-3xl relative overflow-hidden"
          >
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent pointer-events-none"></div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 relative z-10">Want to see how I'd approach your <span className="text-primary glow-text">business?</span></h2>
            <Link to="/contact" className="relative z-10 inline-block">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 hover:brightness-110 rounded-full px-10 h-14 text-lg btn-glow border-none font-bold">
                Let's talk
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </main>
  );
}