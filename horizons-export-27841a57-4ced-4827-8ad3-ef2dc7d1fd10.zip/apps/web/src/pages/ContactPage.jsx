import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Linkedin, Terminal } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ContactPage() {
  return (
    <main className="min-h-screen pt-24 pb-20 bg-background relative overflow-hidden">
      <Helmet>
        <title>Contact Us | RakeshProTech</title>
      </Helmet>

      {/* Abstract Background */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-20 right-10 w-[500px] h-[500px] bg-primary/10 rounded-full mix-blend-screen filter blur-[120px] opacity-40"></div>
        <div className="absolute bottom-20 left-10 w-[600px] h-[600px] bg-secondary/10 rounded-full mix-blend-screen filter blur-[130px] opacity-30"></div>
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPgo8cmVjdCB3aWR0aD0iNCIgaGVpZ2h0PSI0IiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9IjAuMDIiLz4KPC9zdmc+')] opacity-20 mix-blend-overlay"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/10 border border-primary/30 rounded-full text-primary text-sm font-medium mb-6 shadow-[0_0_10px_rgba(0,229,255,0.1)]">
            <Terminal className="w-4 h-4" /> System Online
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight">Initiate <span className="text-primary glow-text">Protocol</span></h1>
          <p className="text-xl text-foreground/80">
            Ready to scale operations? Establish a connection for a technical strategy audit.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          
          {/* Form Section */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-7 glass-card p-8 md:p-12 rounded-3xl"
          >
            <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-3">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse shadow-[0_0_8px_rgba(0,229,255,0.8)]"></span>
              Data Transmission
            </h2>
            <form action="mailto:rakeshrockstar928@gmail.com" method="POST" encType="text/plain" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-foreground/60 uppercase tracking-wider">Entity Name</label>
                  <input type="text" name="Name" required className="w-full px-5 py-4 rounded-xl bg-input/80 border border-border focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary focus:shadow-[0_0_15px_rgba(0,229,255,0.2)] text-white placeholder:text-foreground/30 transition-all" placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-foreground/60 uppercase tracking-wider">Comms Address</label>
                  <input type="email" name="Email" required className="w-full px-5 py-4 rounded-xl bg-input/80 border border-border focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary focus:shadow-[0_0_15px_rgba(0,229,255,0.2)] text-white placeholder:text-foreground/30 transition-all" placeholder="john@company.com" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-foreground/60 uppercase tracking-wider">Direct Line (Optional)</label>
                <input type="tel" name="Phone" className="w-full px-5 py-4 rounded-xl bg-input/80 border border-border focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary focus:shadow-[0_0_15px_rgba(0,229,255,0.2)] text-white placeholder:text-foreground/30 transition-all" placeholder="+1 (555) 000-0000" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-foreground/60 uppercase tracking-wider">System Requirements</label>
                <textarea name="Message" rows="5" required className="w-full px-5 py-4 rounded-xl bg-input/80 border border-border focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary focus:shadow-[0_0_15px_rgba(0,229,255,0.2)] text-white placeholder:text-foreground/30 transition-all resize-none" placeholder="Detail your current bottlenecks and target metrics..."></textarea>
              </div>
              <Button type="submit" className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl h-14 text-base font-bold btn-glow animate-pulse-glow border-none mt-4">
                Transmit Data
              </Button>
            </form>
          </motion.div>

          {/* Sidebar Section */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="lg:col-span-5 space-y-6"
          >
            <div className="glass-card p-8 rounded-3xl h-full border-secondary/20 shadow-[0_0_20px_rgba(168,85,247,0.05)]">
              <h3 className="text-xl font-bold text-white mb-8">Node Locations</h3>
              <div className="space-y-8">
                <a href="tel:+919632047883" className="flex items-start gap-5 group">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-all shadow-[0_0_10px_rgba(0,229,255,0.1)]">
                    <Phone className="w-5 h-5 text-primary group-hover:drop-shadow-[0_0_5px_rgba(0,229,255,0.8)] transition-all" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-foreground/60 uppercase tracking-wider mb-1">Encrypted Voice / WhatsApp</p>
                    <p className="text-white font-medium group-hover:text-primary transition-colors">+91 96320 47883</p>
                  </div>
                </a>
                
                <a href="mailto:rakeshrockstar928@gmail.com" className="flex items-start gap-5 group">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-all shadow-[0_0_10px_rgba(0,229,255,0.1)]">
                    <Mail className="w-5 h-5 text-primary group-hover:drop-shadow-[0_0_5px_rgba(0,229,255,0.8)] transition-all" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-foreground/60 uppercase tracking-wider mb-1">Direct Packet Routing</p>
                    <p className="text-white font-medium break-all group-hover:text-primary transition-colors">rakeshrockstar928@gmail.com</p>
                  </div>
                </a>
                
                <div className="flex items-start gap-5">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(0,229,255,0.1)]">
                    <MapPin className="w-5 h-5 text-primary drop-shadow-[0_0_5px_rgba(0,229,255,0.5)]" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-foreground/60 uppercase tracking-wider mb-1">Physical Coordinates</p>
                    <p className="text-white font-medium">Bengaluru, India</p>
                  </div>
                </div>
                
                <a href="https://www.linkedin.com/in/rakeshprotech/" target="_blank" rel="noreferrer" className="flex items-start gap-5 group">
                  <div className="w-12 h-12 rounded-xl bg-secondary/10 border border-secondary/30 flex items-center justify-center shrink-0 group-hover:bg-secondary/20 transition-all shadow-[0_0_10px_rgba(168,85,247,0.1)]">
                    <Linkedin className="w-5 h-5 text-secondary group-hover:drop-shadow-[0_0_5px_rgba(168,85,247,0.8)] transition-all" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-foreground/60 uppercase tracking-wider mb-1">Professional Network</p>
                    <p className="text-white font-medium group-hover:text-secondary transition-colors">Establish LinkedIn Link</p>
                  </div>
                </a>
              </div>
              
              <div className="mt-12 pt-8 border-t border-primary/10">
                <a href="https://wa.me/919632047883" target="_blank" rel="noreferrer" className="block w-full">
                  <Button className="w-full bg-transparent border border-[#25D366] text-[#25D366] hover:bg-[#25D366]/10 rounded-xl h-14 shadow-[0_0_15px_rgba(37,211,102,0.1)] hover:shadow-[0_0_20px_rgba(37,211,102,0.2)] transition-all">
                    Initiate WhatsApp Chat
                  </Button>
                </a>
              </div>
            </div>
          </motion.div>
          
        </div>
      </div>
    </main>
  );
}