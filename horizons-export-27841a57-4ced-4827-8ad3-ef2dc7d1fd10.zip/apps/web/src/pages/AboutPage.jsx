import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { CheckCircle2 } from 'lucide-react';
export default function AboutPage() {
  return <main className="min-h-screen pt-24 pb-20 bg-background">
      <Helmet>
        <title>About Rakesh M R | RakeshProTech</title>
        <meta name="description" content="Meet Rakesh M R — Digital Marketing Executive at Boston Institute of Analytics and founder of RakeshProTech, blending performance marketing with a cybersecurity and IT background." />
      </Helmet>

      <section className="py-16 relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-secondary/10 rounded-full mix-blend-screen filter blur-[120px] opacity-40 pointer-events-none"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
            
            <motion.div initial={{
            opacity: 0,
            x: -30
          }} animate={{
            opacity: 1,
            x: 0
          }} transition={{
            duration: 0.6
          }} className="lg:col-span-5 lg:sticky lg:top-32">
              <div className="rounded-2xl overflow-hidden shadow-[0_0_30px_rgba(0,229,255,0.15)] aspect-[4/5] border border-primary/30 relative group animate-float-slow">
                <div className="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10 pointer-events-none"></div>
                <img src="https://horizons-cdn.hostinger.com/27841a57-4ced-4827-8ad3-ef2dc7d1fd10/chatgpt-image-jun-19-2026-11_32_25-pm-eOj4p.png" alt="Rakesh M R" className="w-full h-full object-cover grayscale opacity-80 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-700" />
              </div>
            </motion.div>

            <motion.div initial={{
            opacity: 0,
            x: 30
          }} animate={{
            opacity: 1,
            x: 0
          }} transition={{
            duration: 0.6,
            delay: 0.2
          }} className="lg:col-span-7">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-8 tracking-tight">The Architect Behind <br /><span className="text-primary glow-text">RakeshProTech</span></h1>
              
              <div className="prose prose-lg text-foreground/80 mb-12 max-w-none">
                <p>
                  I'm Rakesh M R, a Digital Marketing Professional based in Bengaluru with a non-traditional path to marketing. I started in customer support, moved into IT support, then sales, and finally discovered my passion in digital marketing. That journey taught me how businesses actually work — from the inside out.
                </p>
                <p>
                  Today, I'm a Digital Marketing Executive at Boston Institute of Analytics, where I manage real campaigns with real budgets. Alongside that, I run RakeshProTech — a digital marketing and tech-consulting practice for startups, educational institutions, and local businesses who need someone who actually executes, not just strategizes.
                </p>
                <p>
                  What sets me apart? I'm not just a marketer. I have a background in cybersecurity (EC-Council CSCU), IT fundamentals (CompTIA ITF+), and software programming (IANT). That technical foundation means I understand the systems behind the marketing — not just the dashboards. I approach every campaign with a data-driven, tech-savvy mindset.
                </p>
              </div>

              <h3 className="text-2xl font-bold text-white mb-8">System Evolution</h3>
              {/* FLAG CSS BUG: The timeline currently shows only 2 of 6 steps visible due to a CSS spacing or overflow issue. All 6 steps should render without overlapping. This requires a separate CSS fix to ensure full timeline visibility on desktop and mobile. */}
              <div className="space-y-6 mb-16 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-primary/80 before:via-secondary/50 before:to-primary/10">
                {[{
                role: 'Customer Support',
                desc: 'Decoding human behavior and pain points.'
              }, {
                role: 'IT Support',
                desc: 'Building technical resilience and troubleshooting logic.'
              }, {
                role: 'Sales',
                desc: 'Mastering the psychology of conversion.'
              }, {
                role: 'Digital Marketing',
                desc: 'Fusing tech and psychology for scalable acquisition.'
              }, {
                role: 'Boston Institute of Analytics',
                desc: 'Deploying enterprise-grade campaign architectures.'
              }, {
                role: 'RakeshProTech',
                desc: 'Consulting and executing growth systems for modern business.'
              }].map((item, i) => <motion.div key={i} initial={{
                opacity: 0,
                y: 20
              }} whileInView={{
                opacity: 1,
                y: 0
              }} viewport={{
                once: true
              }} transition={{
                delay: i * 0.1
              }} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                    <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-background bg-primary/20 text-primary shadow-[0_0_15px_rgba(0,229,255,0.4)] shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10 backdrop-blur-md">
                      <span className="text-xs font-bold">{i + 1}</span>
                    </div>
                    <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-5 glass-card rounded-xl group-hover:border-primary/50 transition-all">
                      <h4 className="font-bold text-white mb-1">{item.role}</h4>
                      <p className="text-sm text-foreground/70">{item.desc}</p>
                    </div>
                  </motion.div>)}
              </div>

              <h3 className="text-2xl font-bold text-white mb-6">Technical Credentials</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-16">
                {['Google Digital Marketing', 'Meta Blueprint Certified', 'EC-Council CSCU', 'CompTIA ITF+', 'IANT Software Programmer'].map((cert, i) => <motion.div key={i} initial={{
                opacity: 0,
                scale: 0.95
              }} whileInView={{
                opacity: 1,
                scale: 1
              }} viewport={{
                once: true
              }} transition={{
                delay: i * 0.05
              }} className="flex items-center gap-3 p-4 glass-card rounded-lg">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0 drop-shadow-[0_0_5px_rgba(0,229,255,0.8)]" />
                    <span className="font-medium text-white/90">{cert}</span>
                  </motion.div>)}
              </div>

              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} className="glass-card p-10 rounded-2xl relative overflow-hidden border-primary/40 shadow-[0_0_30px_rgba(0,229,255,0.1)]">
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 blur-[50px]"></div>
                <h3 className="text-2xl font-bold text-white mb-4 relative z-10">Operational Philosophy</h3>
                <p className="text-foreground/80 mb-8 relative z-10 leading-relaxed">
                  Marketing shouldn't be a black box. I believe in complete transparency, data-backed decisions, and treating your budget like it's my own. If a strategy isn't working, we pivot. If it is, we scale aggressively.
                </p>
                <Link to="/contact" className="relative z-10 inline-block">
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 h-12 btn-glow animate-pulse-glow border-none font-bold">
                    Initialize Partnership
                  </Button>
                </Link>
              </motion.div>
            </motion.div>

          </div>
        </div>
      </section>
    </main>;
}