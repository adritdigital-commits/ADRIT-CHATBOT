import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import CourseCard from '@/components/CourseCard.jsx';
import { useScrollAnimation } from '@/hooks/useScrollAnimation.js';
import { courses } from '@/data/coursesData.js';
import { GraduationCap } from 'lucide-react';

function CoursesPage() {
  const [heroRef, heroVisible] = useScrollAnimation(0.1);
  const [coursesRef, coursesVisible] = useScrollAnimation(0.1);

  return (
    <>
      <Helmet>
        <title>Digital Marketing Courses - Rakeshprotech.Online</title>
        <meta name="description" content="Learn digital marketing from an expert. Courses on Meta Ads, Google Ads, SEO, and brand building with practical, real-world strategies." />
      </Helmet>

      <Header />

      {/* Hero Section */}
      <section 
        ref={heroRef}
        className={`py-20 bg-gradient-to-br from-[#1a2d3d] to-[#2a4d6d] text-white transition-opacity duration-1000 ${
          heroVisible ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <GraduationCap className="w-8 h-8" />
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight" style={{letterSpacing: '-0.02em'}}>
            Digital marketing courses
          </h1>
          <p className="text-xl text-white/90 leading-relaxed mb-4">
            Learn practical digital marketing skills from real-world experience
          </p>
          <p className="text-lg text-white/70 italic">
            Learning never ends...
          </p>
        </div>
      </section>

      {/* Courses Grid Section */}
      <section 
        ref={coursesRef}
        className={`py-20 bg-white transition-opacity duration-1000 ${
          coursesVisible ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1a2d3d] mb-4" style={{letterSpacing: '-0.02em'}}>
              Available courses
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed">
              Comprehensive courses designed to give you practical skills you can apply immediately
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            {courses.map((course) => (
              <CourseCard key={course.id} {...course} />
            ))}
          </div>
          <div className="bg-[#1a2d3d] text-white rounded-2xl p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Personalized learning experience</h3>
            <p className="text-white/90 leading-relaxed max-w-3xl mx-auto">
              All courses are personally delivered by Rakesh M R. You will learn from real campaign examples, get answers to your specific questions, and receive ongoing support even after course completion. This is not just another online course—it's mentorship.
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}

export default CoursesPage;