import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { blogData } from '@/data/mockData.js';

export default function BlogPage() {
  return (
    <main className="min-h-screen pt-24 pb-20">
      <Helmet>
        <title>Blog | RakeshProTech</title>
      </Helmet>

      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-6">Insights & Strategies</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Actionable advice on digital marketing, lead generation, and business growth.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogData.map((post) => {
              const formattedDate = new Date(post.date).toLocaleDateString('en-US', {
                month: 'long', day: 'numeric', year: 'numeric'
              });

              return (
                <article key={post.id} className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col">
                  <Link to={`/blog/${post.slug}`} className="block aspect-video overflow-hidden relative">
                    <img 
                      src={post.thumbnail} 
                      alt={post.title} 
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-4 left-4 bg-white/90 backdrop-blur text-primary text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                      {post.category}
                    </div>
                  </Link>
                  <div className="p-6 flex flex-col flex-grow">
                    <div className="text-sm text-muted-foreground mb-3">{formattedDate}</div>
                    <Link to={`/blog/${post.slug}`}>
                      <h2 className="text-xl font-bold text-primary mb-3 hover:text-accent transition-colors line-clamp-2">
                        {post.title}
                      </h2>
                    </Link>
                    <p className="text-muted-foreground mb-6 flex-grow line-clamp-3">
                      {post.excerpt}
                    </p>
                    <Link to={`/blog/${post.slug}`} className="mt-auto flex items-center text-primary font-medium hover:text-accent transition-colors">
                      Read More <ArrowRight className="ml-2 w-4 h-4" />
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>
    </main>
  );
}