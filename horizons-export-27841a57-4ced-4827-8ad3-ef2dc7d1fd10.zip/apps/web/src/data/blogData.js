export const blogData = [
  {
    id: 1,
    slug: 'future-of-ai-in-digital-marketing',
    title: 'The Future of AI in Digital Marketing: What to Expect in 2026',
    category: 'AI',
    excerpt: 'Discover how artificial intelligence is reshaping customer targeting, content creation, and campaign optimization.',
    content: '<p>Artificial Intelligence is no longer just a buzzword; it is the engine driving modern digital marketing...</p><h2>Predictive Analytics</h2><p>By analyzing historical data, AI can predict future consumer behavior with remarkable accuracy...</p>',
    author: 'Rakesh M R',
    date: '2026-05-15',
    thumbnail: 'https://images.unsplash.com/photo-1677442136019-21780ecad995'
  },
  {
    id: 2,
    slug: 'essential-seo-strategies',
    title: '5 Essential SEO Strategies for Local Businesses',
    category: 'Digital Marketing',
    excerpt: 'Learn the foundational SEO tactics that will help your local business dominate search results in your area.',
    content: '<p>Local SEO is critical for brick-and-mortar businesses. If you are not appearing in the local pack, you are losing customers...</p><h2>Optimize Google Business Profile</h2><p>Your GBP is your most valuable local SEO asset...</p>',
    author: 'Rakesh M R',
    date: '2026-04-28',
    thumbnail: 'https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a'
  },
  {
    id: 3,
    slug: 'high-converting-landing-pages',
    title: 'Anatomy of a High-Converting Landing Page',
    category: 'Website Development',
    excerpt: 'Stop losing ad spend on poorly designed pages. Here is exactly how to structure a landing page that converts.',
    content: '<p>A landing page has one job: conversion. Every element on the page must support that single goal...</p><h2>The Hero Section</h2><p>You have 3 seconds to capture attention. Your headline must be clear and benefit-driven...</p>',
    author: 'Rakesh M R',
    date: '2026-04-10',
    thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f'
  }
];