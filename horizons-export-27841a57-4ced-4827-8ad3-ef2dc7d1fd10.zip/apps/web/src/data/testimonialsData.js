export const testimonialsData = [
  {
    id: 1,
    name: 'Full Transparency on Every Campaign',
    role: 'Core Principle',
    text: 'You get clear reporting, honest metrics, and no fluff. I explain what\'s working, what\'s not, and why.',
    rating: 5,
    theme: 'navy'
  },
  {
    id: 2,
    name: 'You Talk Directly to Me, Not an Account Manager',
    role: 'Core Principle',
    text: 'As a founder, I personally manage your campaigns and strategy. No middlemen, no handoffs.',
    rating: 5,
    theme: 'white'
  },
  {
    id: 3,
    name: 'Data-Driven, Not Guesswork',
    role: 'Core Principle',
    text: 'Every decision is backed by analytics, testing, and real performance data — not creative hunches.',
    rating: 5,
    theme: 'white'
  }
];