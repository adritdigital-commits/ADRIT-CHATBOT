export const servicesData = [
  {
    id: 'meta-google-ads',
    title: 'Meta Ads & Google Ads Management',
    description: 'Certified, data-driven ad campaigns that drive leads and sales.',
    icon: 'Target',
    details: 'We build and manage high-performing ad campaigns across Meta (Facebook/Instagram) and Google. Our approach focuses on ROI, not just clicks.',
    included: ['Account Audit & Setup', 'Audience Research & Targeting', 'Ad Copywriting & Creative Direction', 'Continuous A/B Testing', 'Conversion Tracking Setup'],
    process: ['Discovery', 'Strategy & Build', 'Launch', 'Optimize & Scale']
  },
  {
    id: 'lead-generation',
    title: 'Lead Generation & Funnel Building',
    description: 'Custom funnels designed to convert prospects into customers.',
    icon: 'Filter',
    details: 'Stop losing potential customers. We design end-to-end sales funnels that capture attention, nurture leads, and drive conversions automatically.',
    included: ['Landing Page Design', 'Lead Magnet Creation', 'Email Sequence Automation', 'CRM Integration', 'Funnel Analytics'],
    process: ['Map the Journey', 'Build Assets', 'Integrate Systems', 'Test & Refine']
  },
  {
    id: 'social-media',
    title: 'Social Media Marketing & Content Creation',
    description: 'Engaging content and community growth across platforms.',
    icon: 'Share2',
    details: 'Build a loyal audience with strategic content that resonates. We handle everything from ideation to publishing and community management.',
    included: ['Content Strategy', 'Graphic Design & Video Editing', 'Copywriting', 'Scheduling & Publishing', 'Community Engagement'],
    process: ['Brand Voice Definition', 'Content Calendar', 'Production', 'Distribution']
  },
  {
    id: 'branding',
    title: 'Branding & Creative Strategy',
    description: 'Build a brand that stands out and resonates with your audience.',
    icon: 'Palette',
    details: 'Your brand is more than a logo. We help you define your visual identity, messaging, and positioning to stand out in a crowded market.',
    included: ['Brand Identity Design', 'Messaging Framework', 'Visual Guidelines', 'Marketing Collateral', 'Brand Positioning'],
    process: ['Research', 'Concept Development', 'Refinement', 'Guidelines Delivery']
  },
  {
    id: 'web-design',
    title: 'WordPress Website Design & Development',
    description: 'Fast, SEO-friendly websites that convert visitors.',
    icon: 'Layout',
    details: 'Your website is your digital storefront. We build custom WordPress sites that are fast, secure, and optimized for search engines and conversions.',
    included: ['Custom UI/UX Design', 'Responsive Development', 'On-Page SEO Setup', 'Speed Optimization', 'Security Implementation'],
    process: ['Wireframing', 'Design Mockups', 'Development', 'Testing & Launch']
  },
  {
    id: 'analytics',
    title: 'Marketing Analytics & Campaign Reporting',
    description: 'Transparent reporting and data-driven optimization.',
    icon: 'BarChart3',
    details: 'Know exactly where your marketing dollars are going. We provide clear, actionable insights to help you make informed business decisions.',
    included: ['Custom Dashboards', 'GA4 Setup & Configuration', 'Tag Manager Implementation', 'Monthly Performance Reviews', 'Actionable Insights'],
    process: ['Audit Tracking', 'Setup Dashboards', 'Data Collection', 'Monthly Reporting']
  }
];

export const blogData = [
  {
    id: '1',
    slug: 'maximize-roi-google-ads',
    title: 'How to Maximize ROI with Google Ads in 2026',
    category: 'Digital Marketing',
    date: '2026-06-15',
    author: 'Rakesh M R',
    excerpt: 'Discover the latest strategies to lower your CPC and increase conversions using AI-driven bidding and precise targeting.',
    content: '<p>Google Ads has evolved significantly. To stay ahead, you need to leverage automation while maintaining strategic control...</p>',
    thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: '2',
    slug: 'high-converting-landing-pages',
    title: 'The Anatomy of a High-Converting Landing Page',
    category: 'Website Development',
    date: '2026-06-02',
    author: 'Rakesh M R',
    excerpt: 'A breakdown of the essential elements every landing page needs to turn visitors into qualified leads.',
    content: '<p>Your ad might be perfect, but if your landing page fails to convert, your budget is wasted. Here is what you need...</p>',
    thumbnail: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: '3',
    slug: 'b2b-lead-generation-strategies',
    title: 'B2B Lead Generation Strategies That Actually Work',
    category: 'Lead Generation',
    date: '2026-05-20',
    author: 'Rakesh M R',
    excerpt: 'Move beyond cold calling. Learn how to build a predictable pipeline of B2B leads using LinkedIn and targeted content.',
    content: '<p>B2B buyers are doing more research than ever before engaging with sales. Your marketing needs to meet them where they are...</p>',
    thumbnail: 'https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=800&auto=format&fit=crop'
  }
];

export const portfolioData = [
  {
    id: '1',
    title: 'Boston Institute of Analytics',
    industry: 'Education Sector',
    challenge: 'Managing Meta Ads and Google Ads campaigns for professional certification and career programs.',
    solution: 'Handling lead generation funnels, campaign reporting, and creative direction for an education-sector brand.',
    results: 'Ongoing Campaign Management'
  },
  {
    id: '2',
    title: 'International Institute of Business Studies',
    industry: 'Academic Institution',
    challenge: 'Creating digital content, managing social media, and supporting brand presence.',
    solution: 'Delivered photography, videography, and website updates to maintain a strong digital footprint.',
    results: '4+ Years of Brand Support'
  },
  {
    id: '3',
    title: 'RakeshProTech — Freelance & Consulting',
    industry: 'Startups & Local Business',
    challenge: 'Providing independent digital marketing and tech consulting on a project basis.',
    solution: 'Delivered social media marketing, WordPress websites, and lead generation support.',
    results: 'Successful Project Deliveries'
  }
];