export const servicesData = [
  {
    id: 'digital-marketing',
    title: 'Digital Marketing',
    icon: 'Target',
    description: 'Data-driven campaigns that capture attention and convert visitors into loyal customers.',
    features: ['Search Engine Optimization (SEO)', 'Pay-Per-Click Advertising (PPC)', 'Social Media Marketing', 'Email Marketing Campaigns']
  },
  {
    id: 'website-development',
    title: 'Website Development',
    icon: 'Monitor',
    description: 'High-performance, conversion-optimized websites built for modern businesses.',
    features: ['Custom Web Design', 'E-commerce Solutions', 'Landing Page Optimization', 'Website Maintenance']
  },
  {
    id: 'ai-automations',
    title: 'AI Automations',
    icon: 'Cpu',
    description: 'Streamline your operations and save hours of manual work with intelligent automation.',
    features: ['Customer Support Chatbots', 'Workflow Automation', 'CRM Integration', 'Data Processing Systems']
  },
  {
    id: 'online-branding',
    title: 'Online Branding',
    icon: 'Sparkles',
    description: 'Build a memorable digital identity that stands out in a crowded marketplace.',
    features: ['Brand Strategy', 'Visual Identity Design', 'Content Creation', 'Reputation Management']
  }
];