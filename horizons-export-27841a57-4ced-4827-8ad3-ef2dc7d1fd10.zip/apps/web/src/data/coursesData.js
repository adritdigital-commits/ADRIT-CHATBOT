export const courses = [
  {
    id: 1,
    title: 'Meta Ads Mastery',
    level: 'Intermediate',
    lessons: 12,
    description: 'Master Facebook and Instagram advertising from campaign setup to advanced optimization techniques. Learn to create profitable ad campaigns.',
    price: 1999,
    features: [
      'Campaign structure & setup',
      'Audience targeting strategies',
      'Creative best practices',
      'Conversion optimization',
      'Scaling profitable campaigns',
      'Real campaign case studies'
    ]
  },
  {
    id: 2,
    title: 'Google Ads For Beginners',
    level: 'Beginner',
    lessons: 10,
    description: 'Complete beginner-friendly guide to Google Ads. Start running profitable search campaigns even with zero prior experience.',
    price: 1499,
    features: [
      'Google Ads fundamentals',
      'Keyword research methods',
      'Writing compelling ad copy',
      'Landing page basics',
      'Budget management',
      'Performance tracking'
    ]
  },
  {
    id: 3,
    title: 'Digital Marketing Starter',
    level: 'Beginner',
    lessons: 8,
    description: 'Perfect introduction to digital marketing covering SEO, social media, email marketing, and basic paid advertising concepts.',
    price: 999,
    features: [
      'Digital marketing overview',
      'SEO fundamentals',
      'Social media basics',
      'Email marketing intro',
      'Content marketing',
      'Analytics essentials'
    ]
  },
  {
    id: 4,
    title: 'Build Your Brand Online',
    level: 'Beginner',
    lessons: 9,
    description: 'Learn to establish and grow your personal or business brand online through strategic content and community building.',
    price: 1299,
    features: [
      'Brand positioning',
      'Content strategy',
      'Social media branding',
      'Community building',
      'Personal branding',
      'Brand consistency'
    ]
  }
];