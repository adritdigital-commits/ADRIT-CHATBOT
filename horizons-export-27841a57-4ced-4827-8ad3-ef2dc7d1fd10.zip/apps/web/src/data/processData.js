export const processData = [
  {
    step: '01',
    title: 'Discovery Call',
    description: 'We start by understanding your business, goals, target audience, and current challenges to ensure we are the right fit.'
  },
  {
    step: '02',
    title: 'Strategy Development',
    description: 'I craft a customized, data-driven roadmap detailing exactly how we will achieve your specific growth objectives.'
  },
  {
    step: '03',
    title: 'Implementation',
    description: 'We execute the strategy with precision, building the assets, launching campaigns, and setting up automation systems.'
  },
  {
    step: '04',
    title: 'Optimization & Growth',
    description: 'Continuous monitoring, testing, and refining to maximize ROI and scale your results over the long term.'
  }
];